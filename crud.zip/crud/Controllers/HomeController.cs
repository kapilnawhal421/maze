﻿using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using crud.Models;
using System.Data.SqlClient;
using System.Data;
using System;

namespace crud.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            LevelDbContext db = new LevelDbContext();
            List<Level> obj = db.getLevel();

            return View(obj);
        }


        public ActionResult Create()
        {
           
            return View();
        }
        [HttpPost]
        public ActionResult Create(Level level)
        {
            try
            {
                if (ModelState.IsValid == true)
                {
                    LevelDbContext context = new LevelDbContext();
                    bool check = context.AddLevel(level);
                    if (check == true)
                    {
                        TempData["InsertMassage"] = "Level has been Created successfully";
                        ModelState.Clear();
                        return RedirectToAction("Index");
                    }
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(string levelcode)
        {
            LevelDbContext context = new LevelDbContext();
            var row = context.getLevel().Find(model => model.LEVEL_Code == levelcode);
            return View(row);
        }

        [HttpPost]
        public ActionResult Edit(string levelcode, Level level)
        {
            if (ModelState.IsValid == true)
            {
                LevelDbContext context = new LevelDbContext();
                bool check = context.UpdateLevel(level);
                if (check == true)
                {
                    TempData["UpdateMessage"] = "Data has been Updated Successfully.";
                    ModelState.Clear();
                    return RedirectToAction("Index");
                }

            }

            return View();
        }

     
        public ActionResult Delete(string levelcode)
        {
            LevelDbContext context = new LevelDbContext();
            var row = context.getLevel().Find(model => model.LEVEL_Code == levelcode);
            return View(row);
        }
        [HttpGet]
        [ActionName("getlevel")]
        public List<Level> getlevel()
        {
            List<Level> LevelList = new List<Level>();
            string cs = "Data Source =localhost ;Initial Catalog=DEMO;User Id=sa;Password=Strong1234;";
            SqlConnection con = new SqlConnection(cs);
            string Q = "sp_Level_details";
            SqlCommand cmd = new SqlCommand(Q, con);
            //SqlDataAdapter sda = new SqlDataAdapter(Q, con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Level leveldetail = new Level();
                leveldetail.LEVEL_Code = dr.GetValue(0).ToString();
                leveldetail.Description = dr.GetValue(1).ToString();
                leveldetail.Active = dr.GetValue(2).ToString();
                LevelList.Add(leveldetail);



            }
            con.Close();
            //DataSet ds = new DataSet();
            //sda.Fill(ds);
            //return Ok(ds);

            return LevelList;

        }

        [HttpPost]
        [ActionName("Addlevel")]
        public bool AddLevel(String levelcode,String description,String active)
        {
            string cs = "Data Source =localhost ;Initial Catalog=DEMO;User Id=sa;Password=Strong1234;";
            SqlConnection con = new SqlConnection(cs);
            string Q = "sp_Level_detailsInsert";
            SqlCommand cmd = new SqlCommand(Q, con);
            //SqlDataAdapter sda = new SqlDataAdapter(Q, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@LEVEL_Code", levelcode);
            cmd.Parameters.AddWithValue("@Description", description);
            cmd.Parameters.AddWithValue("@Active", active);


            con.Open();
            int returnValue = cmd.ExecuteNonQuery();

            if (returnValue > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        [HttpDelete]
        [ActionName("Deletelevel")]
        public bool DeleteLevel(String levelCode)
        {
           
                string cs = "Data Source =localhost ;Initial Catalog=DEMO;User Id=sa;Password=Strong1234;";
                SqlConnection con = new SqlConnection(cs);
                string Q = "sp_Level_detailsDelete";
                SqlCommand cmd = new SqlCommand(Q, con);
                //SqlDataAdapter sda = new SqlDataAdapter(Q, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@LEVEL_Code", levelCode);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();

                if (i > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
       



        [HttpPost]
        [ActionName("Updatelevel")]
        public bool UpdateLevel(String levelcode, String description, String active)
        {
            string cs = "Data Source =localhost ;Initial Catalog=DEMO;User Id=sa;Password=Strong1234;";
            SqlConnection con = new SqlConnection(cs);
            string Q = "sp_Level_detailsUpdate";
            SqlCommand cmd = new SqlCommand(Q, con);
            //SqlDataAdapter sda = new SqlDataAdapter(Q, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LEVEL_Code", levelcode);
            cmd.Parameters.AddWithValue("@Description", description);
            cmd.Parameters.AddWithValue("@Active", active);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }




        [HttpPost]
            public ActionResult Delete(string levelcode, Level level)
        {

            LevelDbContext context = new LevelDbContext();
            bool check = context.DeleteLevel(levelcode);
            if (check == true)
            {
                TempData["DeleteMessage"] = "Data has been Deleted Successfully.";
                return RedirectToAction("Index");
            }
            return View();
        }

    



public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
