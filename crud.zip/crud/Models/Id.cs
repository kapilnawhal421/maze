﻿using System;
namespace crud.Models
{
    public class Id
    {
        public int column_1 { get; set; }

    }
}